package exceptions;

import simulation.Rescuable;
import model.units.Unit;

public abstract class UnitException extends SimulationException{
	
	Unit unit;
	Rescuable target;
	
	public UnitException(Unit unit,Rescuable target){
		super();
	}
	
	public UnitException(Unit unit,Rescuable target, String message){
		super(message);
	}
	
	public Unit getUnit() {
		return unit;
	}
	public Rescuable getTarget() {
		return target;
	}
}
