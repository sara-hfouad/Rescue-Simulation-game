package model.units;

import javafx.scene.AmbientLight;
import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import model.disasters.Collapse;
import model.disasters.Disaster;
import model.disasters.Fire;
import model.disasters.GasLeak;
import model.disasters.Infection;
import model.disasters.Injury;
import model.events.SOSResponder;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;

public abstract class Unit implements Simulatable, SOSResponder {
	private String unitID;
	private UnitState state;
	private Address location;
	private Rescuable target;
	private int distanceToTarget;
	private int stepsPerCycle;
	private WorldListener worldListener;

	public Unit(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener) {
		this.unitID = unitID;
		this.location = location;
		this.stepsPerCycle = stepsPerCycle;
		this.state = UnitState.IDLE;
		this.worldListener = worldListener;
	}

	public void setWorldListener(WorldListener listener) {
		this.worldListener = listener;
	}

	public WorldListener getWorldListener() {
		return worldListener;
	}

	public UnitState getState() {
		return state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public Address getLocation() {
		return location;
	}

	public void setLocation(Address location) {
		this.location = location;
	}

	public String getUnitID() {
		return unitID;
	}

	public Rescuable getTarget() {
		return target;
	}

	public int getStepsPerCycle() {
		return stepsPerCycle;
	}

	public void setDistanceToTarget(int distanceToTarget) {
		this.distanceToTarget = distanceToTarget;
	}

	@Override
	public void respond(Rescuable r) throws CannotTreatException, IncompatibleTargetException{
		
		
	
		if(canTreat(r)==false){
			CannotTreatException ex=new CannotTreatException(this, r, "This target cannot be treated");
			throw(ex);
		}

		else{
			
			if(r instanceof Citizen){
				Citizen c=(Citizen)r;
				if(this instanceof FireTruck || this instanceof GasControlUnit || this instanceof Evacuator){
					IncompatibleTargetException ex=new IncompatibleTargetException(this,c,"This unit is incompatible with the target");
					throw(ex);
				}
			}
			
			else {
				ResidentialBuilding rb=(ResidentialBuilding) r;
				if(this instanceof Ambulance|| this instanceof DiseaseControlUnit){
					IncompatibleTargetException ex2=new IncompatibleTargetException(this,rb,"This unit is incompatible with the target");
					throw(ex2);
				}
				else if(this instanceof Evacuator && (rb.getDisaster() instanceof Fire || rb.getDisaster() instanceof GasLeak)){
					CannotTreatException ex2=new CannotTreatException(this,rb,"This target cannot be treated");
					throw(ex2);
				}
				else if(this instanceof FireTruck && (rb.getDisaster() instanceof Collapse || rb.getDisaster() instanceof GasLeak)){
					CannotTreatException ex2=new CannotTreatException(this,rb,"This target cannot be treated");
					throw(ex2);
				}
				else if(this instanceof GasControlUnit && (rb.getDisaster() instanceof Fire || rb.getDisaster() instanceof Collapse)){
					CannotTreatException ex2=new CannotTreatException(this,rb,"This target cannot be treated");
					throw(ex2);
				}
				
			}
		}
		if (target != null && state == UnitState.TREATING)
			reactivateDisaster();
		
		finishRespond(r);
		
		
		
	}

	public void reactivateDisaster() {
		Disaster curr = target.getDisaster();
		curr.setActive(true);
	}

	public void finishRespond(Rescuable r) {
		target = r;
		state = UnitState.RESPONDING;
		Address t = r.getLocation();
		distanceToTarget = Math.abs(t.getX() - location.getX())
				+ Math.abs(t.getY() - location.getY());

	}

	public abstract void treat();

	public void cycleStep() {
		if (state == UnitState.IDLE)
			return;
		if (distanceToTarget > 0) {
			distanceToTarget = distanceToTarget - stepsPerCycle;
			if (distanceToTarget <= 0) {
				distanceToTarget = 0;
				Address t = target.getLocation();
				worldListener.assignAddress(this, t.getX(), t.getY());
			}
		} else {
			state = UnitState.TREATING;
			treat();
		}
	}

	public void jobsDone() {
		target = null;
		state = UnitState.IDLE;

	}
	public boolean canTreat(Rescuable r){
		if(r==null)
			return false;
		if(r instanceof Citizen){
			Citizen c=(Citizen)r;
			if((c.getBloodLoss()>0) || (c.getToxicity()>0) || c.getState()==CitizenState.IN_TROUBLE){
				return true;
			}
			
		}
		else{
			ResidentialBuilding rb=(ResidentialBuilding)r;
			if((rb.getGasLevel()>0) || (rb.getFireDamage()>0)
			|| (rb.getFoundationDamage()>0)){
				return true;
			}
			
		}
		return false;
	}
	
	public String getType(){
		if(this instanceof Ambulance)
			return "Ambulance";
		
		if(this instanceof DiseaseControlUnit)
			return "Disease Control Unit";
		
		if(this instanceof FireTruck)
			return "Fire Truck";
		
		if(this instanceof GasControlUnit)
			return "Gas Control Unit";
		
		if(this instanceof Evacuator)
			return "Evacuator";
		
		return "";
	}
	public String toString(){
		if(this ==null)
			return "";
		
		String s="";
		s+="Unit's ID: "+ unitID +"\n";
		s+="Unit Type: "+getType()+"\n";
		s+="Location : ("+location.getX()+","+location.getY()+")"+"\n";
		s+="Steps per cyle: "+stepsPerCycle+"\n";		
		s+="State = "+state+"\n";
		if(this instanceof Evacuator){
			Evacuator e=(Evacuator)this;
			s+="Number of passengers: " + e.getPassengers().size() +"\n";
			if(e.getPassengers().size()>0)
				s+="Passengers:\n";
			for (int i = 0; i < e.getPassengers().size(); i++) {
				s+=e.getPassengers().get(i).toString()+"\n";
			}
		}
		if(target==null)
			s+="Target: null \n";
		else {
			if(target instanceof Citizen)
				s+="Target: \n"+"Citizen: "+((Citizen)target).getName()+
				"\nLocation : ("+target.getLocation().getX()+","+target.getLocation().getY()+")"+"\n";
			else 
				s+="Target: \n"+"ResidentialBuilding" + "\nLocation : ("+
						target.getLocation().getX()+","+target.getLocation().getY()+")"+"\n";
		
		}
		return s;
	}
}
