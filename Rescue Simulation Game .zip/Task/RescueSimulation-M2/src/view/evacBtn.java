package view;

import javax.swing.JButton;;

public class evacBtn extends JButton {
	
	public evacBtn(){
		super();
	}
}
