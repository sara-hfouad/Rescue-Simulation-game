package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import model.units.Unit;


@SuppressWarnings("serial")
public class popupAmb extends JFrame{
	
	private ArrayList<JButton> ambU;
	private JPanel units;
	
	public popupAmb(ArrayList<Unit> ambunits){
		this.setTitle("AMBULANCES");
		this.setBackground(Color.BLACK);
		this.setForeground(Color.orange);
		this.setVisible(true);
		this.setSize(300, 300);
		ambU=new ArrayList<>();
		units=new JPanel();
		this.add(units);
		units.setLayout(new BoxLayout(units, BoxLayout.PAGE_AXIS));
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		addUnits(ambunits);	
		
	}
	
	public void addUnits(ArrayList<Unit> ambunits){
		
		for (int i = 0; i < ambunits.size(); i++) {
			Unit amb=ambunits.get(i);
			JButton b =new JButton();
			b.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
			b.setPreferredSize(new Dimension(130,50));
			b.setText(amb.getUnitID());
			units.add(b);
			ambU.add(b);
		}
	}
	
	public ArrayList<JButton> getAmbU(){
		return ambU;
	}

}
