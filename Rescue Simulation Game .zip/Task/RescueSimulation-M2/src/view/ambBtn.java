package view;

import javax.swing.JButton;

public class ambBtn extends JButton{
	
	public ambBtn(){
		super();
	}
}
