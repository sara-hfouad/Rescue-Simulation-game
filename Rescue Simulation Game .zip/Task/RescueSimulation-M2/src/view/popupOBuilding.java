package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import simulation.Rescuable;
import model.people.Citizen;
 

@SuppressWarnings("serial")
public class popupOBuilding extends JFrame{
	
	private ArrayList<JButton> OccBuilding;
	public  boolean flag;
	private ArrayList<Rescuable> resc;
	private JPanel panel;
	
	public popupOBuilding(ArrayList<Rescuable> r){
		this.setVisible(true);
		this.setSize(300, 300);
		OccBuilding=new ArrayList<>();
		resc=r;
		//System.out.println(resc);
		panel=new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setForeground(Color.orange);
		this.add(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		addResc(r);
		
	}
	
	public void addResc(ArrayList<Rescuable> r){
		for (int i = 0; i < r.size(); i++) {
			Rescuable tmp=r.get(i);
			JButton b =new JButton();
			b.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
			b.setPreferredSize(new Dimension(130,50));
			if(tmp instanceof Citizen)
				b.setText(((Citizen)tmp).getName());
			else
				b.setText("Residential Building");
			panel.add(b);
			OccBuilding.add(b);
		}
	}
	

	public ArrayList<JButton> getOccBuilding (){
		return OccBuilding;
	}
	
	public int getBtnPos(JButton b){
		if(b==null)
			return -1;
		for (int i = 0; i < OccBuilding.size(); i++) {
			if(b.equals(OccBuilding.get(i)))
				return i;
		}
		return -1;
	}
	
	public Rescuable getResc(int i){
		if(i<0)
			return null;
		return resc.get(i);
	}
	
}
