package view;

import javax.swing.JButton;;

public class gasBtn extends JButton{
	
	public gasBtn(){
		super();
	}
}
