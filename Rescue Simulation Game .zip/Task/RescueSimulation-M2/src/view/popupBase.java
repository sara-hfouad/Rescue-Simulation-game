package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;

import model.people.Citizen;
import model.units.Ambulance;
import model.units.DiseaseControlUnit;
import model.units.Evacuator;
import model.units.FireTruck;
import model.units.GasControlUnit;
import model.units.Unit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

@SuppressWarnings("serial")
public class popupBase extends JFrame{
	
	private JTextArea infoU;
	private JTextArea infoC;
	private JPanel grid;
	
	private JScrollPane scrollLeft;
	private JScrollPane scrollRight;
	
	private JLabel lcit;
	private JLabel lamb;
	private JLabel lfire;
	private JLabel lgas;
	private JLabel levac;
	private JLabel ldis;
	
	public popupBase(ArrayList<Unit> u, ArrayList<Citizen> c){
		this.setVisible(true);
		this.setTitle("BASE");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(1500,1500);
		
		grid=new JPanel();
		grid.setBackground(Color.WHITE);
		grid.setForeground(Color.orange);
		grid.setLayout(new GridLayout(3,2));
		this.add(grid,BorderLayout.CENTER);
		
		lamb=new JLabel();
		ldis=new JLabel();
		levac=new JLabel();
		lfire=new JLabel();
		lgas=new JLabel();
		lcit=new JLabel();
		

		lamb.setIcon(new ImageIcon("ambBlack.png"));
		ldis.setIcon(new ImageIcon("dis.png"));
		levac.setIcon(new ImageIcon("evac.jpg"));
		lfire.setIcon(new ImageIcon("fire.png"));
		lgas.setIcon(new ImageIcon("gasB.jpg"));
		lcit.setIcon(new ImageIcon("people.png"));
		
		
		infoU= new JTextArea();
		infoU.setBackground(Color.BLACK);
		infoU.setForeground(Color.orange);
		scrollLeft=new JScrollPane(infoU,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollLeft.setPreferredSize(new Dimension(400,400));
		scrollLeft.setBackground(Color.BLACK);
		scrollLeft.setForeground(Color.orange);
		this.add(scrollLeft,BorderLayout.WEST);
		infoU.setEditable(false);
		infoU.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
		infoU.setPreferredSize(new Dimension(400,3500));
		infoU.validate();
		scrollLeft.validate();

		infoC= new JTextArea();
		infoC.setBackground(Color.BLACK);
		infoC.setForeground(Color.orange);
		scrollRight=new JScrollPane(infoC,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollRight.setPreferredSize(new Dimension(400,400));
		scrollRight.setBackground(Color.BLACK);
		scrollRight.setForeground(Color.orange);
		this.add(scrollRight,BorderLayout.EAST);
		infoC.setEditable(false);
		infoC.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
		infoC.setPreferredSize(new Dimension(400,3500));
		infoC.validate();
		scrollRight.validate();

		
		this.validate();
		addInfo(u,c);
		updateGrid(u,c);
	}
	
	public void addInfo(ArrayList<Unit> units, ArrayList<Citizen> ctzn){
		String u="";
		String c="";
	
		if(units.size()!=0){
			u+="Units : \n";
			for(int i=0;i<units.size();i++){			
				u+=	units.get(i).toString()+"\n";
			}
			u+="\n\n\n\n\n";
		}
		
		
		if(ctzn.size()!=0){
			c+="Citizens : \n";
			for(int i=0;i<ctzn.size();i++){			
				c+=	ctzn.get(i).toString()+"\n";
			}
			c+="\n\n\n\n\n";
		}
		
		infoU.setText(u);	
		infoC.setText(c);	
			
	}
	
	public void updateGrid(ArrayList<Unit> units, ArrayList<Citizen> ctzn){
		ArrayList<Unit> ambU =new ArrayList<>();
		ArrayList<Unit> fireU =new ArrayList<>();
		ArrayList<Unit> evacU =new ArrayList<>();
		ArrayList<Unit> disU =new ArrayList<>();
		ArrayList<Unit> gasU =new ArrayList<>();
		
		for(int i=0;i<units.size();i++){
			Unit u=units.get(i);
			if(u instanceof Ambulance)
				ambU.add(u);
			if(u instanceof FireTruck)
				fireU.add(u);
			if(u instanceof GasControlUnit)
				gasU.add(u);
			if(u instanceof Evacuator)
				evacU.add(u);
			if(u instanceof DiseaseControlUnit)
				disU.add(u);
		}
		

		
		if(ambU.size()>0)
			grid.add(lamb);
		
			
		if(disU.size()>0)
			grid.add(ldis);
		
		if(fireU.size()>0)
			grid.add(lfire);
		
		if(evacU.size()>0)
			grid.add(levac);
		
		if(gasU.size()>0)
			grid.add(lgas);
		
		if(ctzn.size()>0)
			grid.add(lcit);
		
	}
	
	public static void main(String[]args){
		
	}
}
