package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;

import controller.CommandCenter;

public class StartView extends JFrame implements ActionListener{

	JButton start;
	JButton how;
	JButton quit;
	JLabel title;
	JLabel background;
	public StartView(){
		
		validate();
		setDefaultCloseOperation(EXIT_ON_CLOSE);				
		setTitle("RESCUE SIMULATION GAME");
		setLocationRelativeTo(null);
		setVisible(true);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		
		background=new JLabel(new ImageIcon("birdhungergames.jpg"));
		
		getContentPane().add(background);
		background.setLayout(null);
		
		
		///title
		title=new JLabel(new ImageIcon("hungergamestitle.jpg"));
		title.setBounds(80,20,500,80);
		title.setVisible(true);
		
		
		
		
		//start button
		start=new JButton();
		start.setText("START GAME");
		start.setBounds(150,150,400,100);
		start.setForeground(Color.ORANGE);
		start.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 25));
		start.setBackground(Color.BLACK);
		start.setBorder(new LineBorder(Color.orange));
		start.setActionCommand("start");
		start.addActionListener(this);
		start.setVisible(true);
		
		//how to play button
		how=new JButton();
		how.setText("HOW TO PLAY");
		how.setBounds(150,300,400,100);
		how.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 25));
		how.setForeground(Color.ORANGE);
		how.setBackground(Color.BLACK);
		how.setActionCommand("how");
		how.addActionListener(this);
		how.setBorder(new LineBorder(Color.orange));
		how.setVisible(true);
		
		//quit button
		quit=new JButton();
		quit.setText("QUIT GAME");
		quit.setBounds(150,450,400,100);
		quit.setForeground(Color.ORANGE);
		quit.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 25));
		quit.setBorder(new LineBorder(Color.orange));
		quit.setBackground(Color.BLACK);
		quit.setActionCommand("quit");
		quit.addActionListener(this);
		quit.setVisible(true);
		
		background.add(title);
		background.add(start,BorderLayout.NORTH);
		background.add(how,BorderLayout.CENTER);
		background.add(quit,BorderLayout.SOUTH);
		
		this.validate();
		this.setVisible(true);
		
}
	
	public static void main(String [] args){
		new StartView();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("how")){
			new popupHow();
		}
		if(e.getActionCommand().equals("start")){
			try {
				this.dispose();
				new CommandCenter();
			
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getActionCommand().equals("quit")){
			this.dispose();
		}
		
	}
}
