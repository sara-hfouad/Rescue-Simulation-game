package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import model.units.Unit;

@SuppressWarnings("serial")
public class popupFire extends JFrame{
	
	private ArrayList<JButton> fireU;
	private JPanel units;
	
	public popupFire(ArrayList<Unit> fireunits){
		this.setVisible(true);
		this.setSize(300, 300);
		fireU=new ArrayList<>();
		units=new JPanel();
		units.setBackground(Color.BLACK);
		units.setForeground(Color.orange);
		this.add(units);
		units.setLayout(new BoxLayout(units, BoxLayout.PAGE_AXIS));
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		addUnits(fireunits);

	}
	
	public void addUnits(ArrayList<Unit> fireunits){
		
		for (int i = 0; i < fireunits.size(); i++) {
			Unit fire=fireunits.get(i);
			JButton b =new JButton();
			b.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
			b.setPreferredSize(new Dimension(130,50));
			b.setText(fire.getUnitID());
			units.add(b);
			fireU.add(b);
		}
	}
	
	public ArrayList<JButton> getFireU(){
		return fireU;
	}
}
