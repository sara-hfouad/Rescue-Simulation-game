package view;

import javax.swing.JButton;;

public class fireBtn extends JButton{
	
	public fireBtn(){
		super();
	}
}
