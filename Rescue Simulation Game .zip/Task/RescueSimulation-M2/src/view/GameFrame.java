package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.ScrollPane;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.LineBorder;

import model.disasters.Disaster;
import model.people.Citizen;
import model.units.Unit;
import simulation.Simulator;
import simulation.Rescuable;

import com.sun.javafx.tk.Toolkit;
import com.sun.prism.Image;

public class GameFrame extends JFrame{
	

	private JPanel RescuePanel;
	private JTextArea info;
	private JPanel availableunits;
	private JTextArea currentcycle ;
	private JTextArea casualties;
	private JButton cycle;
	//private JButton respond;
	public ambBtn amb;
	private fireBtn fire;
	private evacBtn evac;
	private gasBtn gas;
	private diseaseBtn disease;
	private JButton [] [] buttons;
	private JTextArea disasters;
	private JScrollPane scrollLeft;
	private JScrollPane scrollRight;
	private JButton [] unitsarray;
	private JButton respond;
	private JButton how;
	private JButton sound;
	
	public GameFrame() throws IOException{
		
		buttons = new JButton[10][10];
		unitsarray=new JButton[5];
		
		validate();
		setDefaultCloseOperation(EXIT_ON_CLOSE);				
		setTitle("RESCUE SIMULATION GAME");
		setVisible(true);
		setLocationRelativeTo(null);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		this.setLayout(new BorderLayout());
		
		//////////////////Grid Generation////////////////////////
	
		RescuePanel= new JPanel();
		add(RescuePanel,BorderLayout.CENTER);
	   	RescuePanel.setBackground(Color.WHITE);
		RescuePanel.setLayout(new GridLayout(10,10));
		for(int i=0;i<10;i++){
			for(int j=0;j<10;j++){
				JButton b=new JButton();
				b.setPreferredSize(new Dimension(60,60));
				b.setIcon(new ImageIcon("back6.jpg"));
				b.setBackground(Color.WHITE);
				buttons[i][j]=b;
				RescuePanel.add(b);
				
				}
			}
		RescuePanel.validate();		
	
		//////////////////////InfoPanel///////////////////////		
		info = new JTextArea();
		scrollRight=new JScrollPane(info,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollRight.setPreferredSize(new Dimension(350, getHeight()));
		scrollRight.setBackground(Color.BLACK);
		add(scrollRight,BorderLayout.EAST);
		info.setPreferredSize(new Dimension(350,2000));
		info.setEditable(false);
		info.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
		info.setForeground(Color.orange);
		info.setEditable(false);
		info.setBackground(Color.BLACK);
		info.setLayout(new FlowLayout());
		info.validate();
				
		/////////////////////Available Units////////////////////////
		 availableunits=new JPanel();
		 availableunits.setBackground(Color.black);
		 availableunits.setLayout(new BorderLayout());
		 getContentPane().add(availableunits,BorderLayout.WEST);
		 availableunits.validate();
		 
		 			   		//// "av units" Text Area///
		 JTextArea txt = new JTextArea();
		 txt.setEditable(false);
		 txt.setBackground(Color.black);
		 txt.setForeground(Color.orange);
		 txt.setPreferredSize(new Dimension(300,30));
		 txt.setFont(new Font(Font.DIALOG, Font.BOLD, 18));
		 txt.setText("                    AVAILABLE UNITS \n");
	   	 availableunits.add(txt,BorderLayout.PAGE_START);
	   	 txt.validate();
	   	 
	   	 				//// exec disasters & active disasters/////
		disasters=new JTextArea();
		disasters.setBackground(Color.black);
		scrollLeft=new JScrollPane(disasters,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollLeft.setBackground(Color.black);
		scrollLeft.setPreferredSize(new Dimension(350,550));
		availableunits.add(scrollLeft,BorderLayout.SOUTH);
		disasters.setEditable(false);
		disasters.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
		disasters.setForeground(Color.orange);
		disasters.setPreferredSize(new Dimension(350,3000));
		disasters.validate();
		scrollLeft.validate();
			
	   	 
	   	 					//// units insertion area////
		 JPanel units=new JPanel();
		 units.setForeground(Color.orange);
		 units.setBackground(Color.BLACK);
		 units.setPreferredSize(new Dimension(350,100));
		 availableunits.add(units,BorderLayout.CENTER);
		units.validate();
		 
		amb=new ambBtn();
		amb.setPreferredSize(new Dimension(65,65));
		amb.setIcon(new ImageIcon("aB.png"));
		amb.setBackground(Color.WHITE);
		units.add(amb);
		amb.validate(); 
		
		fire=new fireBtn();
		fire.setPreferredSize(new Dimension(65,65));
		fire.setIcon(new ImageIcon("fireU.png"));
		fire.setBackground(Color.WHITE);
		units.add(fire);
		fire.validate();
		
		evac=new evacBtn();
		evac.setPreferredSize(new Dimension(65,65));
		evac.setIcon(new ImageIcon("evacU.jpg"));
		evac.setBackground(Color.WHITE);
		units.add(evac);
		evac.validate();
		
		gas=new gasBtn();
		gas.setPreferredSize(new Dimension(65,65));
		gas.setIcon(new ImageIcon("gas.jpg"));
		gas.setBackground(Color.WHITE);
		units.add(gas);
		gas.validate();
		
		disease=new diseaseBtn();
		disease.setPreferredSize(new Dimension(65,65));
		disease.setIcon(new ImageIcon("disU.png"));
		disease.setBackground(Color.WHITE);
		units.add(disease);
		disease.validate();
		
		///////////////////Bottom area///////////////////
		
		 JPanel bottom =new JPanel();
		// JLabel background=new JLabel(new ImageIcon("bottomback.jpg"));
		// bottom.add(background);
		 bottom.setBackground(Color.black);
	   	 //bottom.setBounds(0,400,100,50);
	   	add(bottom,BorderLayout.SOUTH);
	   	bottom.validate();
	   	
				//////Cycle-Casualities-Respond Info////////
		
	   	how = new JButton();
	   	how.setText("How to play");
	   	how.setBorder(new LineBorder(Color.orange));
	   	//how.setIcon(new ImageIcon("bottomback.jpg"));
	   	how.setForeground(Color.orange);
	   	how.setBackground(Color.BLACK);
	   	how.setPreferredSize(new Dimension(110,30));
	   	how.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
		bottom.add(how);
		how.validate();
		
		sound = new JButton();
		sound.setText("Mute");
		//sound.setActionCommand("mute");
		//sound.setIcon(new ImageIcon("bottomback.jpg"));
		sound.setForeground(Color.orange);
		sound.setBorder(new LineBorder(Color.orange));
	   	sound.setBackground(Color.BLACK);
		sound.setPreferredSize(new Dimension(70,30));
		sound.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
		bottom.add(sound);
		sound.validate();
		
		
		cycle = new JButton();
		cycle.setText("Next Cycle");
		//how.setIcon(new ImageIcon("smokeback.jpg"));
		cycle.setForeground(Color.orange);
		//cycle.setIcon(new ImageIcon("bottomback.jpg"));
		cycle.setBorder(new LineBorder(Color.orange));
	   	cycle.setBackground(Color.BLACK);
		cycle.setPreferredSize(new Dimension(110,30));
		cycle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
		bottom.add(cycle);
		cycle.validate();
		
		
		
		currentcycle =new JTextArea();
		currentcycle.setEditable(false);
		currentcycle.setBorder(new LineBorder(Color.orange));
		currentcycle.setForeground(Color.orange);
	   	currentcycle.setBackground(Color.BLACK);
		currentcycle.setText(" Current Cycle:      ");
		currentcycle.setPreferredSize(new Dimension(130,25));
		currentcycle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
		//currentcycle.setBackground(Color.BLACK);
		bottom.add(currentcycle);
		currentcycle.validate();
		
		casualties = new JTextArea();
		casualties.setForeground(Color.orange);
	   	casualties.setBackground(Color.BLACK);
		casualties.setEditable(false);
		casualties.setBorder(new LineBorder(Color.ORANGE));
		casualties.setPreferredSize(new Dimension(130,25));
		casualties.setText(" Casualties:       ");
		casualties.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
		//casualties.setBackground(Color.RED);
		bottom.add(casualties);
		casualties.validate();
		
		
		
		
	    ////////////////////respond button/////////////////////////
	    respond=new JButton();
	   // respond.setIcon(new ImageIcon("smokeback.jpg"));
	    respond.setForeground(Color.orange);
	   	respond.setBackground(Color.BLACK);
	    respond.setText("Respond");
	    respond.setPreferredSize(new Dimension(100,50));
	    respond.validate();
	    
	    this.pack();
	    this.setVisible(true);
		this.validate();
	    
	}
	
	

	////////////////////// add image on button  ////////////////////

	public int getX(JButton b){
		if(b==null)
			return 0;
		for (int i = 0; i < buttons.length; i++) {
			for (int j = 0; j < buttons.length; j++) {
				if(b.equals(buttons[i][j]))
					return i;
			}
		}
		return 0;
	}
	
	public int getY(JButton b){
		if(b==null)
			return 0;
		for (int i = 0; i < buttons.length; i++) {
			for (int j = 0; j < buttons.length; j++) {
				if(b.equals(buttons[i][j]))
					return j;
			}
		}
		return 0;
	}
	
	///////////////////////get button//////////////////////
	public JButton getBtn(int x ,int y){
		return buttons[x][y];
	}
	
	
	//////////////////////updateCycle////////////////////
	public void updateCycle(int c){
		String s="";
		s+="Current Cycle: "+c;
		currentcycle.setText(s);		
	}
	
	//////////////////////updateCasualties ///////////////////
	public void updateCasualties(int c){
		String s="";
		s+="Casualties: "+c;
		casualties.setText(s);		
	}
	
	//////////////////////add info of rescuable on panel//////////////////
	public void updateInfoPanelRescuable(Rescuable r){
		String s="";
		if(r==null)
			info.setText(s);
		else{
		s+="Info: \n"+ r.toString();
		info.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
		info.setText(s);
		
		}
	}
	
	//////////////////////add info of unit on panel//////////////////
	public void updateInfoPanelUnit(ArrayList<Unit> units){		
		if(units ==null){
			info.setText("");
			return ;
		}
		String s="Info: \n";		
		for(int i=0;i<units.size();i++)
			s+=units.get(i).toString()+"\n";
		info.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
		info.setText(s);
		
	}
	
	//////////////////////add info of exception on panel//////////////////
	public void updateInfoPanelEx(String e){
		String s="";
		s+="Info: \n"+ e;
		info.setText(s);
		
	}
	
	////////////////////////Disasters && DeadCtzn ///////////////////////
	
	public void execDisasters(ArrayList<Disaster> execD, ArrayList<Disaster> activeD , ArrayList<Citizen> ctzn){
		String s="";
		s+="Executed Disasters : \n";
		for (int i = 0; i < execD.size(); i++) {
			s+=execD.get(i).display()+", Cycle"+execD.get(i).getStartCycle()+"\n";
		}
		if(activeD.size()>0){
			s+="\nActive Disasters : \n";
			
			for(int j=0; j< activeD.size();j++){
				s+=activeD.get(j).display()+"\n";
			}
		}
		if(ctzn.size()>0){
			s+="\nDead Citizens : \n";
			for (int i = 0; i < ctzn.size(); i++) {
				Citizen c =ctzn.get(i);
				s+=c.getName() + "Location : ("+
				c.getLocation().getX()+","+c.getLocation().getY()+")"+"\n";
			}
		}
		
		s+="\n\n\n\n";
		
		disasters.setText(s);
		
	}
	
	///////////////////get NextCycle button for actionlistener///////////////////////
	public JButton getCycle(){
		return this.cycle;
	}
	////////////////////get InfoPanel////////////////////////////
	public JTextArea getInfoPanel (){
		return this.info;
	}
	
	///////////////////////units getters/////////////////////////////
	public ambBtn getamb(){
		return amb;
	}
	public fireBtn getfire(){
		return fire;
	}
	public diseaseBtn getdisease(){
		return disease;
	}
	public gasBtn getgas(){
		return gas;
	}
	public evacBtn getevac(){
		return evac;
	}
	//////////////////units list getter//////////////////////
	public JButton [] getUnitsList(){
		return unitsarray;
	}
	
	//////////////////get the 2d array of btns/////////////
	public JButton [][] getBtnsList(){
		return buttons;
	}
	
	
	////////////////////BaseInfo//////////////////////
	public void updateBase(ArrayList<Unit> u,ArrayList<Citizen> c){
		String s="";
		if(u==null && c==null){
			info.setText(s);
			return ;
		}
		if(u.size()!=0){
			s+="Units : \n";
			for(int i=0;i<u.size();i++){			
				s+=	u.get(i).toString()+"\n";
			}
		}
		if(c.size()!=0){
			s+="Citizens : \n";
			for(int i=0;i<c.size();i++){			
				s+=	c.get(i).toString()+"\n";
			}
		}
		info.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
		info.setText(s);		
	}
	
	public JButton getHow (){
		return how;
	}



	public JButton getSound() {
		return sound;
	}

}
