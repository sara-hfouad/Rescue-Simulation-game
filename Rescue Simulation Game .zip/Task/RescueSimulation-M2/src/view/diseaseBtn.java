package view;

import javax.swing.JButton;;

public class diseaseBtn extends JButton {
	
	public diseaseBtn() {
		super();
	}
}
