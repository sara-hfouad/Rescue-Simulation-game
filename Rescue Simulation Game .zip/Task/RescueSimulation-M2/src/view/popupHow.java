package view;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

@SuppressWarnings("serial")
public class popupHow extends JFrame{
	
	public popupHow(){
		
		setSize(new Dimension(500,200));
		setTitle("HOW TO PLAY");
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
		
		JTextArea p =new JTextArea();
		p.setBackground(Color.BLACK);
		p.setForeground(Color.orange);
		
		//p.setSize(new Dimension(600,200));
		p.setEditable(false);
		add(p);
		String s=" Welcome to the HUNGER GAMES!!  \n In this game what you will try to do is to save "
				+ "all buildings and citizens which are struck\n by disasters through out the cycles, this is done by making the suitable emergency units\n "
				+ "respond to them which is done by clicking on the rescuable you want to save and then\n choosing the unit "
				+ "which you want to respond to that rescuable. Try to rescue as much\n buildings and citizens as you can "
				+ "before it is GAME OVER! \n Happy Hunger Games! And may the odds be ever in your favor. :) ";
		
		p.setText(s);
		
		
	}
	

}
