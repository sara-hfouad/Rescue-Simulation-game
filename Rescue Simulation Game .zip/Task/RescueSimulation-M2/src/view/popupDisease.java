package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import model.units.Unit;

@SuppressWarnings("serial")
public class popupDisease extends JFrame {
	
	private ArrayList<JButton> diseaseU;
	private JPanel units;

	
	public popupDisease(ArrayList<Unit> diseaseunits){
		this.setVisible(true);
		this.setSize(300, 300);
		diseaseU=new ArrayList<>();
		units=new JPanel();
		units.setBackground(Color.BLACK);
		units.setForeground(Color.orange);
		this.add(units);
		units.setLayout(new BoxLayout(units, BoxLayout.PAGE_AXIS));
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		addUnits(diseaseunits);

	}
	
	public void addUnits(ArrayList<Unit> diseaseunits){
		
		for (int i = 0; i < diseaseunits.size(); i++) {
			Unit disease=diseaseunits.get(i);
			JButton b =new JButton();
			b.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
			b.setPreferredSize(new Dimension(130,50));
			b.setText(disease.getUnitID());
			units.add(b);
			diseaseU.add(b);
		}
	}
	
	public ArrayList<JButton> getDiseaseU(){
		return diseaseU;
	}
}
