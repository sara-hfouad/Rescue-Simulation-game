package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;








import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import exceptions.BuildingAlreadyCollapsedException;
import exceptions.CannotTreatException;
import exceptions.CitizenAlreadyDeadException;
import exceptions.IncompatibleTargetException;
import model.disasters.Disaster;
import model.events.SOSListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import model.units.Unit;
import model.units.Ambulance;
import model.units.Evacuator;
import model.units.FireTruck;
import model.units.DiseaseControlUnit;
import model.units.GasControlUnit;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulator;
import model.disasters.Injury;
import model.disasters.Collapse;
import model.disasters.Fire;
import model.disasters.GasLeak;
import view.GameFrame;
import view.ambBtn;
import view.fireBtn;
import view.gasBtn;
import view.evacBtn;
import view.diseaseBtn;
import view.popupAmb;
import view.popupFire;
import view.popupDisease;
import view.popupGas;
import view.popupEvac;
import view.popupOBuilding;
import view.popupBase;
import view.popupHow;


@SuppressWarnings("serial")
public class CommandCenter extends JFrame implements SOSListener, ActionListener , MouseListener {

	private Simulator engine;
	private GameFrame gameframe;
	private ArrayList<ResidentialBuilding> visibleBuildings;
	private ArrayList<Citizen> visibleCitizens;
	private ArrayList<Unit> emergencyUnits;
	private ArrayList<JButton> btnsCitizen;
	private ArrayList<JButton> btnsBuildings;
	private ArrayList<Citizen> addedCitizens;
	private ArrayList<ResidentialBuilding> addedBuildings;
	private ArrayList<Disaster> execDisasters ;
	private ArrayList<Disaster> activeDisasters ;
	private ArrayList<Citizen> dead;
	public JButton [][] Gridbuttons;
	private popupAmb popupamb ;
	private popupFire popupfire ;
	private popupGas popupgas ;
	private popupEvac popupevac ;
	private popupDisease popupdisease ;
	private popupOBuilding popupobuilding;
	private ArrayList<Unit> Ambunits;
	private ArrayList<Unit> Gasunits;
	private ArrayList<Unit> Diseaseunits;
	private ArrayList<Unit> Fireunits;
	private ArrayList<Unit> Evacunits;
	private boolean rescflag;
	private boolean unitflag;
	private boolean entered;
	private boolean rescflagB;
	private JButton unittype ;
	private JButton rescBtn;
	private boolean occBflag;
	private boolean isResc;
	private boolean Cadded;
	private ArrayList<Address> buildingL;
	private ArrayList<Unit> unitsinBase;
	private ArrayList<Citizen> CinBase;
	private JLabel lamb;
	private JLabel lfire;
	private JLabel lgas;
	private JLabel levac;
	private JLabel ldis;
	private JButton base;
	private Clip clip;
	//private JButton sound;
	
	
	public CommandCenter() throws Exception {
		
		//soundtrack
		
		
		File soundFile= new File("hunger_games_whistle.wav");
		AudioInputStream audioIn= AudioSystem.getAudioInputStream(soundFile);
		
		clip=AudioSystem.getClip();
		clip.open(audioIn);
		clip.start();
		clip.loop(Clip.LOOP_CONTINUOUSLY);
		
		
		///sound buton
		
		
		
		engine = new Simulator(this);
		visibleBuildings = new ArrayList<ResidentialBuilding>();
		visibleCitizens = new ArrayList<Citizen>();
		emergencyUnits = engine.getEmergencyUnits();
		btnsBuildings = new ArrayList<> ();
		btnsCitizen =new ArrayList<>();
		addedCitizens=new ArrayList<>();
		addedBuildings=new ArrayList<>();
		buildingL=new ArrayList<>();
		unitsinBase=new ArrayList<>();
		CinBase=new ArrayList<>();
		
		gameframe=new GameFrame();
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		gameframe.setVisible(true);	
		
		gameframe.getCycle().addActionListener(this);
		gameframe.getHow().addActionListener(this);
		gameframe.getSound().addActionListener(this);
		
		gameframe.getamb().addMouseListener(this);
		gameframe.getfire().addMouseListener(this);
		gameframe.getevac().addMouseListener(this);
		gameframe.getgas().addMouseListener(this);
		gameframe.getdisease().addMouseListener(this);
		
		gameframe.getamb().addActionListener(this);
		gameframe.getfire().addActionListener(this);
		gameframe.getevac().addActionListener(this);
		gameframe.getgas().addActionListener(this);
		gameframe.getdisease().addActionListener(this);
		
		gameframe.getamb().setActionCommand("unit");
		gameframe.getfire().setActionCommand("unit");
		gameframe.getevac().setActionCommand("unit");
		gameframe.getgas().setActionCommand("unit");
		gameframe.getdisease().setActionCommand("unit");
		
		occBflag=false;
		
		execDisasters = engine.getExecutedDisasters();
		activeDisasters=new ArrayList<>();
		Gridbuttons=gameframe.getBtnsList();
		
		Ambunits = new ArrayList<>();
		Fireunits = new ArrayList<>();
		Gasunits = new ArrayList<>();
		Diseaseunits = new ArrayList<>();
		Evacunits = new ArrayList<>();
		dead=new ArrayList<>();
		
		lamb=new JLabel();
		ldis=new JLabel();
		levac=new JLabel();
		lfire=new JLabel();
		lgas=new JLabel();
		
		lamb.setIcon(new ImageIcon("ambOG.png"));
		ldis.setIcon(new ImageIcon("disOG.jpg"));
		levac.setIcon(new ImageIcon("evacOG.jpg"));
		lfire.setIcon(new ImageIcon("fireOG.png"));
		lgas.setIcon(new ImageIcon("gasOG.jpg"));
		
		lamb.setPreferredSize(new Dimension(30,30));
		lfire.setPreferredSize(new Dimension(30,30));
		ldis.setPreferredSize(new Dimension(30,30));
		levac.setPreferredSize(new Dimension(30,30));
		lgas.setPreferredSize(new Dimension(30,30));
		
		
		for(int i=0;i<emergencyUnits.size();i++){
			Unit u =emergencyUnits.get(i);
			if(u instanceof Ambulance){
				Ambunits.add(u);
			}
			else if(u instanceof GasControlUnit){
				Gasunits.add(u);
			}
			else if(u instanceof FireTruck){
				Fireunits.add(u);
			}
			else if(u instanceof Evacuator){
				Evacunits.add(u);
			}
			else if(u instanceof DiseaseControlUnit){
				Diseaseunits.add(u);
			}
		}
		
		for (int i = 0; i <emergencyUnits.size(); i++) {
			Unit u =emergencyUnits.get(i);
				unitsinBase.add(u);			
			
		}
		
		base=gameframe.getBtn(0, 0);
		base.addMouseListener(this);
		base.setBackground(Color.black);
		base.setActionCommand("base");
		//base.setOpaque(false);
		base.setIcon(new ImageIcon("base.png"));
		
		

	}
	
	
	
	public void updateGridRescuable(){
		
		updateunitsB();
		
		int x,y ;
		
		for(int i=0;i<10;i++){
			for(int j=0;j<10;j++){
				if(!(i==0 && j==0)){
				for(int n=0;n<visibleBuildings.size();n++){
					ResidentialBuilding b=visibleBuildings.get(n);					
					
					x=b.getLocation().getX();
					y=b.getLocation().getY();
					
					 if(x==i && y==j){
						JButton btn =gameframe.getBtn(x,y);
						buildingL.add(b.getLocation());
						
						boolean f=false; 
						if(b.getFireDamage()==0 && b.getFoundationDamage()==0 &&b.getGasLevel()==0)
							f=true;
						
						if((b.getStructuralIntegrity() == 100 && !(b.getDisaster() instanceof GasLeak))
							|| (b.getStructuralIntegrity()==100 && b.getGasLevel()==0) || f){
							if(b.getOccupants().size()==0){
								btn.setIcon(new ImageIcon("build.png"));
								btn.setActionCommand("eBuilding");
							}
							else {
								btn.setIcon(new ImageIcon("occBE.png"));
								btn.setActionCommand("oBuilding");
							}
						}
						
						else if(b.getStructuralIntegrity()==0){
							btn.setIcon(new ImageIcon("fallenB.png"));
						}
						
						else if(b.getDisaster() instanceof Collapse){
							btn.setIcon(new ImageIcon("collapseB.jpg"));
							if(b.getOccupants().size()==0)
								btn.setActionCommand("eBuilding");
							
							else 
								btn.setActionCommand("oBuilding");
							
						}
						
						else if(b.getDisaster() instanceof Fire){
							btn.setIcon(new ImageIcon("fireBuilding.png"));
							if(b.getOccupants().size()==0)
								btn.setActionCommand("eBuilding");
							
							else 
								btn.setActionCommand("oBuilding");
							
						}
						else if(b.getDisaster() instanceof GasLeak){
							btn.setIcon(new ImageIcon("gasB.png"));
							if(b.getOccupants().size()==0)
								btn.setActionCommand("eBuilding");
							
							else 
								btn.setActionCommand("oBuilding");
							
						}
						
						btn.addActionListener(this);
						btn.addMouseListener(this);
						if(!btnsBuildings.contains(btn))
							btnsBuildings.add(btn);
						if(!addedBuildings.contains(b))
							addedBuildings.add(b);
						if(b.getDisaster().isActive() && !activeDisasters.contains(b.getDisaster()))
							activeDisasters.add(b.getDisaster());
					 }					
				}
				
				for(int m=0;m<visibleCitizens.size();m++){
					Citizen c=visibleCitizens.get(m);					
					
					x=c.getLocation().getX();
					y=c.getLocation().getY();

					 if(x==i && y==j){
						JButton btn =gameframe.getBtn(x,y);
						Cadded=false;
						
						for (int k = 0; k < buildingL.size(); k++) {
							Address a= buildingL.get(k);
							if(c.getLocation().getX()==a.getX() && c.getLocation().getY()==a.getY()){
								Cadded=true;
								break;
							}
						}
						
						if(!Cadded){
							if(c.getHp()==100 || c.getState()==CitizenState.RESCUED)
								btn.setIcon(new ImageIcon("rescuedC.png"));

							else if(c.getState()==CitizenState.IN_TROUBLE){
								if(c.getDisaster() instanceof Injury)
									btn.setIcon(new ImageIcon("injuredC.png"));
								else 
									btn.setIcon(new ImageIcon("infectedC.png"));
							}
							else if(c.getState()==CitizenState.DECEASED)
								btn.setIcon(new ImageIcon("deadC.png"));
						
							btn.setActionCommand("Citizen");
							btn.addActionListener(this);
							btn.addMouseListener(this);
							if(!btnsCitizen.contains(btn))
								btnsCitizen.add(btn);
							
							if(!addedCitizens.contains(c))
								addedCitizens.add(c);
						
						}
						
						if(c.getDisaster().isActive() && !activeDisasters.contains(c.getDisaster()))
							activeDisasters.add(c.getDisaster());
						
					 }					
				}
			}

			}	
		}
		
		
		for (int i = 0; i <emergencyUnits.size(); i++) {
			Unit u =emergencyUnits.get(i);
			int m=u.getLocation().getX();
			int n=u.getLocation().getY();
			JButton resc=gameframe.getBtn(m,n);
			if(m!=0 && n!=0){
				if(u.getTarget()!=null){
					
									
					if(u instanceof Ambulance){
						resc.add(lamb,BorderLayout.PAGE_START);
					}
					else if(u instanceof GasControlUnit){
						resc.add(lgas,BorderLayout.NORTH);
					}
					else if(u instanceof FireTruck){
						resc.add(lfire,BorderLayout.PAGE_START);
					}
					else if(u instanceof Evacuator){
						resc.add(levac,BorderLayout.NORTH);
					}
					else if(u instanceof DiseaseControlUnit){
						resc.add(ldis,BorderLayout.NORTH);
					}
				}
				
			}
			
			else if(n==0 && m==0 && u instanceof Evacuator && u.getTarget()!=null){
				int a=u.getTarget().getLocation().getX();
				int b=u.getTarget().getLocation().getY();
				
				JButton e=gameframe.getBtn(a, b);
				
				e.remove(levac);
				
			}
			
		}
		

		
	}
	
	 public void updateunitsB(){
		 for (int i = 0; i <emergencyUnits.size(); i++) {
				Unit u =emergencyUnits.get(i);
				if(u.getLocation().getX()==0 &&u.getLocation().getY()==0){
					
					if(!unitsinBase.contains(u)){
						unitsinBase.add(u);			
						
						if(u instanceof Evacuator){
							if(((Evacuator)u).getPassengers()!=null)
								for(int j=0;j<((Evacuator)u).getPassengers().size();j++){
									Citizen c=((Evacuator)u).getPassengers().get(j);
									if(!CinBase.contains(c))
										CinBase.add(c);
								}
						}
					
					}			
				}
				
				else if(u.getLocation().getX()!=0 && u.getLocation().getY()!=0){
					unitsinBase.remove(u);
					}
			}
			
			
	 }
	

	@Override
	public void receiveSOSCall(Rescuable r) {
		
		if (r instanceof ResidentialBuilding) {
			
			if (!visibleBuildings.contains(r))
				visibleBuildings.add((ResidentialBuilding) r);
			
		} else {
			
			if (!visibleCitizens.contains(r))
				visibleCitizens.add((Citizen) r);
		}

	}
	
	public void updateActiveD(){
		for (int i=0;i<activeDisasters.size();i++){
			if(!activeDisasters.get(i).isActive())
				activeDisasters.remove(i);
		}
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() instanceof JButton){
		JButton b= (JButton) e.getSource();
		
		if(b.getText().equals("Mute")){
				clip.stop();
				gameframe.getSound().setText("Unmute");
			
		}
		
		else if(b.getText().equals("Unmute")){
				clip.start();
				clip.loop(Clip.LOOP_CONTINUOUSLY);
				gameframe.getSound().setText("Mute");
			
		}
		
		else if(b.getActionCommand().equals("Citizen")||b.getActionCommand().equals("eBuilding")){
			rescflag=true;
			rescBtn=b;
			isResc=true;
		}
		
		else if(b.getActionCommand().equals("fromOBuilding")){
			rescflagB=true;
			rescBtn=b;
			isResc=false;
		}
		
		else if( b.getActionCommand().equals("oBuilding") && occBflag==false){			
			rescflagB=true;
			isResc=false;
			Rescuable rb=getClickedOBuilding(b);
			if(rb!=null && occBflag==false){
				occBflag=true;
				popupobuilding =new popupOBuilding(getAllLocation(rb.getLocation().getX(),rb.getLocation().getY()));
				setActionOccBuilding(popupobuilding.getOccBuilding());
				 
			}
		}
		
		else if(b.getActionCommand().equals("unit")){
			unitflag=true;
			unittype=b;
		}
		
		
		
		if((rescflag && unitflag) || (rescflagB && unitflag)){
		
			if(unittype instanceof ambBtn){
				
				popupamb=new popupAmb(Ambunits);
				setActionAmb(popupamb.getAmbU());
				
			}
			if(unittype instanceof fireBtn){
				popupfire=new popupFire(Fireunits);
				setActionFire(popupfire.getFireU());
				
				
			}
			if(unittype instanceof diseaseBtn){
				popupdisease=new popupDisease(Diseaseunits);
				setActionDisease(popupdisease.getDiseaseU());
				
			}
			if(unittype instanceof evacBtn){
				popupevac=new popupEvac(Evacunits);
				setActionEvac(popupevac.getEvacU());
				
			}
			if(unittype instanceof gasBtn){
				popupgas=new popupGas(Gasunits);
				setActionGas(popupgas.getGasU());
				
			}
			
			entered=true;
			rescflag=false;
			rescflagB=false;
			unitflag=false;
			occBflag =false;
		}
		
		if( b.getActionCommand().equals("Subunit") && entered){
			Rescuable r =null ;
			if(isResc){
				 r =getResc(rescBtn);
			}
			else {
				Rescuable rOB=popupobuilding.getResc(popupobuilding.getBtnPos(rescBtn));
				r=rOB;
			}
		if(unittype instanceof ambBtn){
				for (int i = 0; i < Ambunits.size(); i++) {
					if(b.getText().equals(Ambunits.get(i).getUnitID())){
						try {
							Ambunits.get(i).respond(r);
						} catch (CannotTreatException
								| IncompatibleTargetException e1) {
							String s="";
							if(e1 instanceof IncompatibleTargetException)
								s=" Choose another unit";
							JOptionPane.showMessageDialog(null, e1.getMessage()+s);

						}
					}
				}
			}
			
		else if(unittype instanceof fireBtn){
				
				for (int i = 0; i < Fireunits.size(); i++) {
					if(b.getText().equals(Fireunits.get(i).getUnitID()))
						try {
							Fireunits.get(i).respond(r);
						} catch (CannotTreatException
								| IncompatibleTargetException e1) {
							String s="";
							if(e1 instanceof IncompatibleTargetException)
								s=" Choose another unit";
							JOptionPane.showMessageDialog(null, e1.getMessage()+s);

						}
				}
			}
			
		else if(unittype instanceof diseaseBtn){
				
				for (int i = 0; i < Diseaseunits.size(); i++) {
					if(b.getText().equals(Diseaseunits.get(i).getUnitID()))
						try {
							Diseaseunits.get(i).respond(r);
						} catch (CannotTreatException
								| IncompatibleTargetException e1) {
							String s="";
							if(e1 instanceof IncompatibleTargetException)
								s=" Choose another unit";
							JOptionPane.showMessageDialog(null, e1.getMessage()+s);
						}
				}
			}
			
		else if(unittype instanceof evacBtn){
				
				for (int i = 0; i < Evacunits.size(); i++) {
					if(b.getText().equals(Evacunits.get(i).getUnitID()))
						try {
							Evacunits.get(i).respond(r);
						} catch (CannotTreatException
								| IncompatibleTargetException e1) {
							String s="";
							if(e1 instanceof IncompatibleTargetException)
								s=" Choose another unit";
							JOptionPane.showMessageDialog(null, e1.getMessage()+s);

						}
				}
			}
			
		else if(unittype instanceof gasBtn){
				
				for (int i = 0; i < Gasunits.size(); i++) {
					if(b.getText().equals(Gasunits.get(i).getUnitID()))
						try {
							Gasunits.get(i).respond(r);
						} catch (CannotTreatException
								| IncompatibleTargetException e1) {
							String s="";
							if(e1 instanceof IncompatibleTargetException)
								s=" Choose another unit";
							JOptionPane.showMessageDialog(null, e1.getMessage()+s);

						}
				}
			}
		
		}
		
		else if(b.getText().equals("Next Cycle")){
			
			try {
				engine.nextCycle();
			} catch (CitizenAlreadyDeadException ex) {
				gameframe.updateInfoPanelEx(ex.getMessage());
			} catch (BuildingAlreadyCollapsedException ex) {
				gameframe.updateInfoPanelEx(ex.getMessage());
			} catch (CannotTreatException ex) {
				gameframe.updateInfoPanelEx(ex.getMessage());
			} catch (IncompatibleTargetException ex) {
				gameframe.updateInfoPanelEx(ex.getMessage());
			}
			checkGameOver();
			 
			gameframe.updateCycle(engine.getCurrentCycle());
			gameframe.updateCasualties(engine.calculateCasualties());
			updateGridRescuable();
			updateActiveD();
			dead=updateDeadC();
			gameframe.execDisasters(execDisasters,activeDisasters,dead);
			
		}
		
		else if(b.getText().equals("How to play")){
			new popupHow();
		}
		
		}
	}

	
	
	
	private ArrayList<Rescuable> getAllLocation(int x, int y) {
		ArrayList<Rescuable> res=new ArrayList<>();
		
		for (int i = 0; i < visibleBuildings.size(); i++) {
			ResidentialBuilding b=visibleBuildings.get(i);
			if(b.getLocation().getX()==x && b.getLocation().getY()==y)
				res.add(b);
		}		
		
		for (int i = 0; i < visibleCitizens.size(); i++) {
			Citizen c=visibleCitizens.get(i);
			if(c.getLocation().getX()==x && c.getLocation().getY()==y)
				res.add(c);
		}	
		//System.out.println(res);

		return res;
	}


	private Rescuable getResc(JButton rescuable) {
		if(rescuable==null)
			return null;
		for (int i = 0; i < Gridbuttons.length; i++) {
			for (int j = 0; j < Gridbuttons.length; j++) {
				if(rescuable.equals(Gridbuttons[i][j])){
					for(int n=0;n<visibleCitizens.size();n++){
						if(visibleCitizens.get(n).getLocation().getX()==i && visibleCitizens.get(n).getLocation().getY()==j)
							return visibleCitizens.get(n);
					}
					for(int n=0;n<visibleBuildings.size();n++){
						if(visibleBuildings.get(n).getLocation().getX()==i && visibleBuildings.get(n).getLocation().getY()==j)
							return visibleBuildings.get(n);
					}
				}
				
			}
		}
		return null;
	}


	
	@Override
	public void mouseClicked(java.awt.event.MouseEvent e) {
		if(e.getSource() instanceof JButton){
			JButton b= (JButton) e.getSource();
			if(b.getActionCommand().equals("base")){
				updateunitsB();
				new popupBase(unitsinBase,CinBase);
			}
		}
	}

	@Override
	public void mouseEntered(java.awt.event.MouseEvent e) {
		if(e.getSource() instanceof JButton){
			JButton b= (JButton) e.getSource();
			
			
			 if(b.getActionCommand().equals("unit")){
				
				if(b instanceof ambBtn)				
					gameframe.updateInfoPanelUnit(Ambunits);				
				
				else if(b instanceof fireBtn)				
					gameframe.updateInfoPanelUnit(Fireunits);				
				
				else if(b instanceof evacBtn)
					gameframe.updateInfoPanelUnit(Evacunits);				
				
				else if(b instanceof gasBtn)
					gameframe.updateInfoPanelUnit(Gasunits);
								
				else if(b instanceof diseaseBtn)
					gameframe.updateInfoPanelUnit(Diseaseunits);
						
					
				}
			
			else if(b.getActionCommand().equals("Citizen")||b.getActionCommand().equals("eBuilding")||b.getActionCommand().equals("oBuilding")){
			
			
					if(btnsCitizen.contains(b)){
						int x=gameframe.getX(b);
						int y=gameframe.getY(b);
						for (int i = 0; i < addedCitizens.size(); i++) {
							Citizen c=addedCitizens.get(i);
							if(c.getLocation().getX()==x && c.getLocation().getY()==y)
								gameframe.updateInfoPanelRescuable(c);	
						}
						
					}
					else if(btnsBuildings.contains(b)){
						int x=gameframe.getX(b);
						int y=gameframe.getY(b);
						for (int i = 0; i < addedBuildings.size(); i++) {
							ResidentialBuilding rb=addedBuildings.get(i);
							if(rb.getLocation().getX()==x && rb.getLocation().getY()==y)
								gameframe.updateInfoPanelRescuable(rb);	
							}
						}
				}
			
		}	
	}
	

	@Override
	public void mouseExited(java.awt.event.MouseEvent e) {
		if(e.getSource() instanceof JButton){
			JButton b= (JButton) e.getSource();
			
			 if(b.getActionCommand().equals("Citizen")||b.getActionCommand().equals("eBuilding")||b.getActionCommand().equals("oBuilding")){
					
					if(btnsCitizen.contains(b)){
						int x=gameframe.getX(b);
						int y=gameframe.getY(b);
						for (int i = 0; i < addedCitizens.size(); i++) {
							Citizen c=addedCitizens.get(i);
							if(c.getLocation().getX()==x && c.getLocation().getY()==y)
								gameframe.updateInfoPanelRescuable(null);	
						}
						
					}
					else if(btnsBuildings.contains(b)){
						int x=gameframe.getX(b);
						int y=gameframe.getY(b);
						for (int i = 0; i < addedBuildings.size(); i++) {
							ResidentialBuilding rb=addedBuildings.get(i);
							if(rb.getLocation().getX()==x && rb.getLocation().getY()==y)
								gameframe.updateInfoPanelRescuable(null);	
							}
						}
				}
			}
		
	}

	@Override
	public void mousePressed(java.awt.event.MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(java.awt.event.MouseEvent e) {
		
		
	}
	
	public void setActionAmb (ArrayList<JButton> ambU){
		for (int i = 0; i < ambU.size(); i++) {
			ambU.get(i).addActionListener(this);
			ambU.get(i).setActionCommand("Subunit");
		}
	}
	
	public void setActionFire (ArrayList<JButton> fireU){
		for (int i = 0; i < fireU.size(); i++) {
			fireU.get(i).addActionListener(this);
			fireU.get(i).setActionCommand("Subunit");
		}
	}
	
	public void setActionEvac (ArrayList<JButton> evacU){
		for (int i = 0; i < evacU.size(); i++) {
			evacU.get(i).addActionListener(this);
			evacU.get(i).setActionCommand("Subunit");
		}
	}
	public void setActionDisease (ArrayList<JButton> diseaseU){
		for (int i = 0; i < diseaseU.size(); i++) {
			diseaseU.get(i).addActionListener(this);
			diseaseU.get(i).setActionCommand("Subunit");
		}
	}
	public void setActionGas (ArrayList<JButton> gasU){
		for (int i = 0; i < gasU.size(); i++) {
			gasU.get(i).addActionListener(this);
			gasU.get(i).setActionCommand("Subunit");
		}
	}
	
	public void setActionOccBuilding (ArrayList<JButton> b){
		for (int i = 0; i < b.size(); i++) {
			b.get(i).addActionListener(this);
			b.get(i).setActionCommand("fromOBuilding");
		}
	}
	
	public Rescuable getClickedOBuilding(JButton b){
		int x=gameframe.getX(b);
		int y=gameframe.getY(b);
		ArrayList<Rescuable> r=getAllLocation(x,y); 
		for (int i = 0; i < r.size(); i++) {
			Rescuable tmp=r.get(i);
			if(tmp instanceof ResidentialBuilding) //.getLocation().getX()==x && tmp.getLocation().getY()==y)
				return tmp;
		}
		return null;
	}
	
	public void checkGameOver(){
		if(engine.checkGameOver()){
			
			Object[] options = {"EXIT","PLAY AGAIN"};
			
		    int n = JOptionPane.showOptionDialog(gameframe,
		    			"GAME OVER LOSER \n YOUR SCORE IS "+engine.calculateCasualties()+ "\n DO YOU WANT TO PLAY AGAIN ?",
		    			"",JOptionPane.PLAIN_MESSAGE,
		                JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
		    if(n == 0){
		    	System.exit(0);
		    }
		    else if (n==1){
		    	try {
					this.dispose();
					new CommandCenter();
				
				} catch (Exception e1) {
					e1.printStackTrace();
				}
		    }
		    else
		    	System.exit(0);
			
		}
	}
	
	public ArrayList<Citizen> updateDeadC(){
		ArrayList<Citizen> dead=new ArrayList<>();
		
		for(int i=0;i<visibleCitizens.size();i++){
			Citizen c=visibleCitizens.get(i);
			if(c.getState()==CitizenState.DECEASED)
				dead.add(c);
		}
		
		for(int i=0;i<visibleBuildings.size();i++){
			ResidentialBuilding b=visibleBuildings.get(i);
			for (int j = 0; j < b.getOccupants().size(); j++) {
				Citizen c=b.getOccupants().get(j);
				if(c.getState()==CitizenState.DECEASED && !dead.contains(c))
					dead.add(c);
			}
		}
		
		return dead;
	}
	
	
	 
}
