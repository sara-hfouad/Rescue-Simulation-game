package simulation;

import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import model.disasters.Disaster;

public interface Rescuable {
public void struckBy(Disaster d) throws CannotTreatException, IncompatibleTargetException;
public Address getLocation();
public Disaster getDisaster();
}
